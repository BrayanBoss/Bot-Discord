import net.dv8tion.jda.api.AccountType;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import javax.security.auth.login.LoginException;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Main extends ListenerAdapter {
    public static void main(String[] args) throws LoginException {
        JDABuilder builder = new JDABuilder(AccountType.BOT);
        String token = "Njc1MjgwNjI5NzU5MzQ0NjQx.XlKROA.hVRK6Xaj8eJW02NkPpOEiWY-H88";
        builder.setToken(token);
        builder.addEventListeners(new Main());
        builder.build();
    }



    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        System.out.println("We received a message from " + event.getAuthor().getName() + " : " + event.getMessage().getContentDisplay());
        Date aujourdhui = new Date();
        DateFormatSymbols FR = new DateFormatSymbols(Locale.FRENCH);
        SimpleDateFormat format = new SimpleDateFormat("'Nous sommes le' EEEE d MMM yyyy, ' il est' hh:mm:ss.",FR);
        if (event.getAuthor().isBot()) return;
        if (event.getMessage().getContentRaw().equals("/ping")) {
            event.getChannel().sendMessage("Pong!").queue();
        }
        if (event.getMessage().getContentRaw().contains("suicid") || event.getMessage().getContentRaw().contains("Suicid")) {
            event.getChannel().sendMessage("Si vous pensez au suicide, ne le faites pas. Le suicide n'est jamais la solution. Appelez SOS AMITIE au `01 40 09 15 22`. Pour ceux qui ne sont pas en France, vous pouvez trouver votre ligne local ici : <http://www.suicide.org/international-suicide-hotlines.html>").queue();
        }
        if (event.getMessage().getContentRaw().equals("/time")) {
            event.getChannel().sendMessage(format.format(aujourdhui)).queue();
        }
        if (event.getMessage().getContentRaw().equals("/help")) {
            event.getAuthor().openPrivateChannel().queue((channel) -> {channel.sendMessage("suce ma queue fdp :thumbsup:").queue();});
            event.getChannel().sendMessage("Regardez dans vos PM, toutes nos commandes y sont ! :grin:").queue();
        }
        if (event.getMessage().getContentRaw().contains("Awo") || event.getMessage().getContentRaw().contains("Awo".toLowerCase()) || event.getMessage().getContentRaw().contains("Awo".toUpperCase())) {
            event.getChannel().sendMessage("Awooooooooooo").queue();
        }
    }
}
